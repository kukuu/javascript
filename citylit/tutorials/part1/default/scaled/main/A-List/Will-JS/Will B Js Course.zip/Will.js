var fruitsPush = ["Banana","Orange","Apple","Mango"];	
var fruitsPop = ["Banana","Orange","Apple","Mango"];
var fruitsShift = ["Banana","Orange","Apple","Mango"];
var str = "Hello World"

function firstcount() {
	var formcontent = document.wordcount.wordcount2.value;
	var content = formcontent.split(" ");
	document.getElementById("wcount").innerHTML = content.length;
}

function charcount() {
	var charcontent = document.wordcount.wordcount2.value;
	var characters = charcontent.length;
	if(characters > 100) {
		document.getElementById("ccount").innerHTML = characters + "<font color=#ff0000> This is too long</font>";
	}
		else {
			document.getElementById("ccount").innerHTML = characters;
		}
}

function alphaSort() {
	var sortcontent = document.wordcount.wordcount2.value;
	var sortList = sortcontent.split(" ");
	var x = document.getElementById("demoSort");
	x.innerHTML = sortList.sort();
}

function passcover() {
	var pwcontent = document.pwbox.password.value;
	var pwlength = pwcontent.length; 
	if (pwlength < 6) {
		document.getElementById("pwoutput").innerHTML = "<font color=#ff0000>  Your password is too short</font>"
	}
		else if (pwlength >= 6 && pwlength <= 10) {
				document.getElementById("pwoutput").innerHTML = "<font color=#009900>  Your password is good</font>"
			}
		else {
			document.getElementById("pwoutput").innerHTML = "<font color=#ff0000>  Your password is too long</font>"
		}

}

function fPush() {
	fruitsPush.push(["Kiwi","Guava","Pineapple"]);
	var x = document.getElementById("demoPush");
	x.innerHTML = fruitsPush;
}


function fJoin() {
	var fruitsJoin = ["Banana","Orange","Apple","Mango"];
	var x = document.getElementById("demoJoin");
	x.innerHTML = fruitsJoin.join();
}

function fPop() {
	fruitsPop.pop();
	var x = document.getElementById("demoPop");
	x.innerHTML = fruitsPop;
}

function fShift() {
	fruitsShift.shift();
	var x = document.getElementById("demoShift");
	x.innerHTML = fruitsShift;
}

function fSub1() {
	document.getElementById("demoSub1").innerHTML = str.substring(3);
}

function fSub2() {
	document.getElementById("demoSub2").innerHTML = str.substring(3,7);
}

function poll() {
	for (var i = 0; i<document.f.rad1.length; i++) {
		if (document.f.rad1[i].checked){
			document.bgColor = document.f.rad1[i].value;
		}
	}
}

document.write("<h1>Multiplication Table</h1>");
document.write("<table border=1 width=50% cellspacing=1 cellpadding=1");
for (var j = 1; j <= 9; j++) {
	document.write("<tr>");
	document.write("<td>" + j + "</td>");
	for (var k = 2; k <= 9; k++) {
		document.write("<td>" + j * k + "</td>");
	}
	document.write("</tr>");
}
document.write("</table>");

function howMany(selectItem) {
	var numberSelected = 0
	for (var l = 0; l < selectItem.options.length; l++) {
		if (selectItem.options[l].selected == true)
			numberSelected++
	}
	document.getElementById("selectTotal").innerHTML = "You have selected " + numberSelected + " guitar brands."
}


function validate(){
	if(document.g.fname.value == '') {
		alert('Enter your first name');
		return;
	}
	else if(document.g.lname.value == '') {
		alert('Enter your last name');
		return;
	}
	else if(document.g.email.value == '') {
		alert('Enter your email');
		return;
	}
	subNow = confirm('Do you want to submit now?');
		if(subNow) {
			document.g.submit();
			document.g.fname.value = '';
			document.g.lname.value = '';
			document.g.email.value = '';
		}
	else {
		return;
	}
}


function countMe(){
	var counter=1;
	while (counter <=7) {
		document.getElementById("counter").innerHTML = "<p style=font-size:" + counter + ";> HTML Font Size " + counter + "</p>";
	counter++;
	}
}

var list = document.getElementById("thumbs");
		var siblings = list.children;

		for (var m = 0; m < siblings.length; m++) {
			siblings[m].addEventListener ("click", showImage);
		}
	function showImage(e) {
		e.preventDefault();
		document.getElementById('imgLarge').src = this.href;
	}