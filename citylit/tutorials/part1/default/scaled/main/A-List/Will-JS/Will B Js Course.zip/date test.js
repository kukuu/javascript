now = new Date();
hour_of_day = now.getHours();
minute_of_hour = now.getMinutes();
seconds_of_minute = now.getSeconds();

document.getElementById("timeNow").innerHTML = "<h2>" + hour_of_day + ":" + minute_of_hour + ":" + seconds_of_minute + "</h2>"
document.getElementById("greetingScript").innerHTML = scriptGreeting
var scriptGreeting = if ((hour_of_day < 10) { "Good Morning"
});
else if ((hour_of_day >= 12) && (hour_of_day <= 17) { "Good Afternoon!"
});
else if ((hour_of_day < 17) {"Good Evening!"
});
else ("Good Day");
